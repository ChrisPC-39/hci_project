import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:hci_project/database/setup.dart';
import 'package:hci_project/screens/phone_main_screen.dart';
import 'package:hci_project/screens/web_main_screen.dart';
import 'package:hci_project/setup_screens/language_screen.dart';
import 'package:hci_project/setup_screens/theme_screen.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter/services.dart';

class SetupScreen extends StatefulWidget {
  @override
  _SetupScreenState createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  int currPage = 0;
  bool canChangeScreen = false;
  final pageController = PageController(initialPage: 0, keepPage: true);

  @override
  Widget build(BuildContext context) {
    final setup = Hive.box("setup").getAt(0) as Setup;
    final bool isEn = setup.lang == "en";

    return ValueListenableBuilder(
      valueListenable: Hive.box("setup").listenable(),
      builder: (context, setupBox, _) {
        return Scaffold(
          appBar: AppBar(title: Text(isEn ? "Set up" : "Set up in Spanish"), backgroundColor: Color(setup.color)),
          body: Column(
            children: [
              _buildTitle(),

              Expanded(
                child: PageView(
                  onPageChanged: (index) => setState(() => currPage = index),
                  physics: BouncingScrollPhysics(),
                  controller: pageController,
                  children: [
                    LanguageScreen(),
                    ThemeScreen(),
                    // QuestionsScreen(),
                    // TimePicker()
                  ]
                )
              ),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  AnimatedOpacity(
                    opacity: currPage > 0 ? 1 : 0,
                    duration: Duration(milliseconds: 500),
                    child: Container(
                      margin: EdgeInsets.fromLTRB(5, 0, 0, 10),
                      child: ElevatedButton(
                        child: Icon(Icons.arrow_back_ios_rounded,
                          size: 35,
                          color: Colors.black
                        ),
                        style: ButtonStyle(
                        minimumSize: MaterialStateProperty.all<Size>(Size.square(60)),
                        shape: MaterialStateProperty.all<CircleBorder>(CircleBorder()),
                        backgroundColor: MaterialStateProperty.resolveWith<Color>(
                            (Set<MaterialState> states) {
                              return Colors.white;
                            }
                          )
                        ),
                        onPressed: () {
                          if (currPage > 0) currPage -= 1;
                          pageController.animateToPage(
                            currPage,
                            duration: Duration(milliseconds: 500),
                            curve: Curves.easeInBack
                          );
                        }
                      )
                    )
                  ),

                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 5, 10),
                      child: ElevatedButton(
                        child: Icon(currPage != 1
                            ? Icons.arrow_forward_ios_rounded
                            : Icons.check,
                            size: 35,
                            color: Colors.black
                        ),
                        style: ButtonStyle(
                            minimumSize: MaterialStateProperty.all<Size>(
                                Size.square(60)),
                            shape: MaterialStateProperty.all<
                                CircleBorder>(CircleBorder()),
                            backgroundColor: MaterialStateProperty
                                .resolveWith<Color>(
                                    (Set<MaterialState> states) {
                                  return Colors.white;
                                }
                            )
                        ),
                        onPressed: () {
                          if (currPage < 1) currPage += 1; //THIS MUST BE CHANGED IF MORE PAGES ARE ADDED
                          pageController.animateToPage(
                            currPage,
                            duration: Duration(milliseconds: 500),
                            curve: Curves.easeInBack
                          );

                          if (canChangeScreen) {
                            final setup = Hive.box("setup").getAt(0) as Setup;
                            Hive.box("setup").putAt(0, Setup(false, setup.lang, setup.color));

                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(builder: (context) =>
                                  kIsWeb ? WebMainScreen() : PhoneMainScreen())
                            );
                          }

                          if (currPage == 1)
                            canChangeScreen = true;
                          else
                            canChangeScreen = false;

                          setState(() {});
                      }
                    )
                  )
                ]
              )
            ]
          )
        );
      }
    );
  }

  Widget _buildTitle() {
    final setup = Hive.box("setup").getAt(0) as Setup;

    return Padding(
      padding: EdgeInsets.only(top: MediaQuery.of(context).size.height * 0.1),
      child: Center(
        child: Container(
          margin: EdgeInsets.fromLTRB(15, 15, 15, 0),
          child: Text(
            setup.lang == "en" ? "Let's begin by setting up your preferences" : "Hola",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 19
            )
          )
        )
      )
    );
  }
}