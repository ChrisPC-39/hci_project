import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hci_project/screens/info_screen.dart';
import 'package:hci_project/screens/phone_main_screen.dart';
import 'package:page_transition/page_transition.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of the application.
  @override
  Widget build(BuildContext context) {
    //This SystemChrome is here to change the colors of the nav bar and status bar
    //on Android phones (the bars that show back/home/menu buttons and the
    //bar that shows time, battery, internet, etc
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarBrightness: Brightness.light,
      statusBarColor: Colors.blue,
      systemNavigationBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Colors.blue
    ));

    return MaterialApp(
      home: PhoneMainScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}