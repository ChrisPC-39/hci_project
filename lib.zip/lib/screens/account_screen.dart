import 'package:flutter/material.dart';

class AccountScreen extends StatefulWidget {
  @override
  _AccountScreenState createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  TextEditingController addressController = TextEditingController();
  TextEditingController phoneController = TextEditingController();

  bool isAdmin = false;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: Text("Account settings")),
        body: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(15),
              child: Align(
                alignment: Alignment(-1.0, 0.0),
                child: Text(
                  "Email and phone numbers are used to send confirmations for successful reports!",
                  style: TextStyle(fontSize: 25, color: Colors.grey[600])
                )
              )
            ),
            _buildEmailAndPhone(isEmail: true),
            _buildEmailAndPhone(isEmail: false),
            Visibility(
              visible: isAdmin,
              child: _buildAdminView()
            ),

            Divider(thickness: 1),

            _buildColorblindSettings()
          ]
        )
      )
    );
  }

  Widget _buildColorblindSettings() {
    return Padding(
      padding: EdgeInsets.all(15),
      child: Column(
        children: [
          Align(
            alignment: Alignment(-1.0, 0.0),
            child: Text("Color settings", style: TextStyle(fontSize: 25, color: Colors.grey[600]))
          ),

          Container(height: 20),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildColorButton("Unaffected", Colors.blue),
              _buildColorButton("Protanopia", Colors.yellow[700]),
              _buildColorButton("Deuteranopia", Colors.red),
            ]
          )
        ]
      )
    );
  }

  Widget _buildColorButton(String text, Color? color) {
    return ElevatedButton(
      onPressed: () {},
      child: Text(text, style: TextStyle(fontSize: 20)),
      style: ButtonStyle(backgroundColor: MaterialStateProperty.all(color)),
    );
  }

  Widget _buildAdminView() {
    return Align(
      alignment: Alignment(-1.0, 0.0),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.8,
        child: ListTile(
          title: Text("Welcome ADMIN! See trash report locations"),
          trailing: Icon(Icons.arrow_forward_ios_rounded),
        )
      ),
    );
  }

  Widget _buildEmailAndPhone({required bool isEmail}) {
    return Padding(
      padding: EdgeInsets.all(15),
      child: Row(
        children: [
          Align(
            alignment: Alignment(-1.0, 0.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.7,
              child: TextField(
                controller: isEmail ? addressController : phoneController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(borderSide: BorderSide(color: Colors.blue)),
                  labelText: isEmail ? "Email addresso si si" : "Phone numbero"
                )
              )
            )
          ),

          Padding(
            padding: EdgeInsets.only(left: 15),
            child: IconButton(
              icon: Icon(Icons.check),
              onPressed: () {
                FocusScope.of(context).unfocus();
                setState(() {
                  if(addressController.text == "1" && phoneController.text == "1")
                    isAdmin = true;
                  else isAdmin = false;
                });
              }
            )
          )
        ]
      )
    );
  }
}
