import 'package:flutter/material.dart';

class InfoScreen extends StatefulWidget {
  @override
  _InfoScreenState createState() => _InfoScreenState();
}

class _InfoScreenState extends State<InfoScreen> {
  String infoTextEN = '''   The aim of this project is to design and build functional prototype front end components for '''
                    '''a rubbish spotting and collection system to be used in Lobitos.''';

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(title: Text("Información / Information")),
        body: Padding(
          padding: EdgeInsets.all(20.0),
          child: ListView(
            physics: BouncingScrollPhysics(),
            children: [
              Text("ESPANOL", style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
              Container(height: 5),
              Text(infoTextEN, style: TextStyle(fontSize: 25)),

              Container(height: 20),
              Divider(thickness: 1),
              Container(height: 20),

              Text("ENGLISH", style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
              Container(height: 5),
              Text(infoTextEN, style: TextStyle(fontSize: 25)),
            ]
          )
        )
      ),
    );
  }
}