import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hci_project/database/setup.dart';
import 'package:hci_project/setup_screens/language_screen.dart';
import 'package:hci_project/setup_screens/theme_screen.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';

class AccountScreen extends StatefulWidget {
  @override
  _AccountScreenState createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  TextEditingController addressController = TextEditingController();
  TextEditingController phoneController = TextEditingController();

  bool isAdmin = false;

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder(
      valueListenable: Hive.box("setup").listenable(),
      builder: (context, setupBox, _) {
        final setup = Hive.box("setup").getAt(0) as Setup;
        final bool isEn = setup.lang == "en";

        return SafeArea(
          child: Scaffold(
            appBar: AppBar(title: Text(isEn ? "Account settings" : "Accounto Settingso"), backgroundColor: Color(setup.color)),
            body: ListView(
              children: [
                Padding(
                  padding: EdgeInsets.all(15),
                  child: Align(
                    alignment: Alignment(-1.0, 0.0),
                    child: Text(
                      isEn ? "Email and phone numbers are used to send confirmations for successful reports!" : "TODO SPANISH",
                      style: TextStyle(fontSize: 25, color: Colors.grey[600])
                    )
                  )
                ),
                _buildEmailAndPhone(isEmail: true),
                _buildEmailAndPhone(isEmail: false),

                Visibility(
                  visible: isAdmin,
                  child: _buildAdminView()
                ),

                Divider(thickness: 1),

                SizedBox(height: 300, child: ThemeScreen()),
                //_buildColorblindSettings(),

                Divider(thickness: 1),

                SizedBox(height: 300, child: LanguageScreen())
              ]
            )
          )
        );
      },
    );
  }

  Widget _buildColorblindSettings() {
    return Padding(
      padding: EdgeInsets.all(15),
      child: Column(
        children: [
          Align(
            alignment: Alignment(-1.0, 0.0),
            child: Text("Color settings", style: TextStyle(fontSize: 25, color: Colors.grey[600]))
          ),

          Container(height: 20),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildColorButton("Unaffected", Colors.blue, 0xFF2196f3),
              _buildColorButton("Protanopia", Colors.yellow[700], 0xFFffbc02d),
              _buildColorButton("Tritanopia", Colors.red[400], 0xFFffef5350),
            ]
          )
        ]
      )
    );
  }

  Widget _buildColorButton(String text, Color? color, int colorCode) {
    return ElevatedButton(
      onPressed: () {
        final setup = Hive.box("setup").getAt(0) as Setup;
        Hive.box("setup").putAt(0, Setup(false, setup.lang, colorCode));
        setSystemChrome();
      },
      child: Text(text, style: TextStyle(fontSize: 20)),
      style: ButtonStyle(backgroundColor: MaterialStateProperty.all(color)),
    );
  }

  Widget _buildAdminView() {
    final setup = Hive.box("setup").getAt(0) as Setup;
    final bool isEn = setup.lang == "en";

    return Align(
      alignment: Alignment(-1.0, 0.0),
      child: Container(
        width: MediaQuery.of(context).size.width * 0.8,
        child: ListTile(
          title: Text(isEn ? "Welcome ADMIN! See trash report locations" : "Wilkommen ADMIN"),
          trailing: Icon(Icons.arrow_forward_ios_rounded),
        )
      )
    );
  }

  Widget _buildEmailAndPhone({required bool isEmail}) {
    final setup = Hive.box("setup").getAt(0) as Setup;
    final bool isEn = setup.lang == "en";

    return Padding(
      padding: EdgeInsets.all(15),
      child: Row(
        children: [
          Align(
            alignment: Alignment(-1.0, 0.0),
            child: Container(
              width: MediaQuery.of(context).size.width * 0.7,
              child: TextField(
                controller: isEmail ? addressController : phoneController,
                decoration: InputDecoration(
                  border: OutlineInputBorder(borderSide: BorderSide(color: Colors.blue)),
                  labelText: isEmail
                      ? isEn ? "Email address" : "Email addresso si si"
                      : isEn ? "Phone number" : "Phone numero"
                )
              )
            )
          ),

          Padding(
            padding: EdgeInsets.only(left: 15),
            child: IconButton(
              icon: Icon(Icons.check),
              onPressed: () {
                FocusScope.of(context).unfocus();
                setState(() {
                  if(addressController.text == "1" && phoneController.text == "1")
                    isAdmin = true;
                  else isAdmin = false;
                });
              }
            )
          )
        ]
      )
    );
  }

  void setSystemChrome() {
    final setup = Hive.box("setup").getAt(0) as Setup;

    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      statusBarBrightness: Brightness.light,
      statusBarColor: Color(setup.color),
      systemNavigationBarIconBrightness: Brightness.light,
      systemNavigationBarColor: Color(setup.color)
    ));
  }
}
